const mongoose = require('mongoose');

const listingSchema=new mongoose.Schema({
    vendorId : String,
    businessCategory : String,
    businessTitle : String,
    description : Array,
    googleMapLocationLink : String,
    email : String,
    phone : String,
    images : Array,
    pricePlans : Array,
    keyFeatures : Array,
    specialOffers : Array
});

module.exports =mongoose.model("listing",listingSchema);