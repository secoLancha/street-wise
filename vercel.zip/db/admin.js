const mongoose = require('mongoose');

const adminSchema=new mongoose.Schema({
    userName : String,
    password : String,
    name : String,
    email : String,
    phone : String,
    // role : String
});

module.exports =mongoose.model("admin",adminSchema);