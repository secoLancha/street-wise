const mongoose = require('mongoose');

const inviteSchema=new mongoose.Schema({
    invitedForRole : String,
    invitedEmail : String,
    invitedByAdmin : String,
    inviteId : String
});

module.exports =mongoose.model("invite",inviteSchema);