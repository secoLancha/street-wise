const mongoose = require('mongoose');

const vendorSchema=new mongoose.Schema({
    userName : String,
    password : String,
    name : String,
    email : String,
    phone : String,
    businessName : String,
    location : String,
    country : String,
    state : String,
    city : String,
    ownerName : String,

    // role : String
});

module.exports =mongoose.model("vendor",vendorSchema);