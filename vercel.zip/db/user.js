const mongoose = require('mongoose');

const userSchema=new mongoose.Schema({
    userName : String,
    password : String,
    name : String,
    email : String,
    phone : String,
    // role : String
});

module.exports =mongoose.model("user",userSchema);